</div><!-- .content -->
<div class="sidebar">
    <h3>Coffee Links</h3>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="view-products.php">View/edit our products</a></li>
        <li><a href="add-products.php">Add a new product</a></li>
    </ul>
    <h3>Coffee Gallery</h3>
    <img src="images/coffeemonkey.jpg" />
    <img src="images/coffeecup.jpg" />
</div><!-- .sidebar -->
</div><!-- .main -->