<?php
    include_once 'header.php';
?>
<p>Your content here.</p>
<?php
    include_once 'sidebar.php';
    include_once 'footer.php';  
?>
